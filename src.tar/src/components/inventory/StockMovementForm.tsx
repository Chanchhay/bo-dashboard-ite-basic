"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent, type ReactNode } from "react";
import {
    ArrowLeft,
    ArrowDownRight,
    ArrowUpRight,
    Calculator,
    Check,
    LoaderCircle,
    Package,
    PackageOpen,
    ScanBarcode,
    SlidersHorizontal,
} from "lucide-react";

import { BarcodeScannerOverlay } from "@/components/inventory/BarcodeScannerOverlay";
import {
    StockTargetSelect,
    toStockTargets,
    type StockTargetRef,
} from "@/components/inventory/stock/StockTargetSelect";
import {
    getApiErrorMessage,
    InventoryError,
    InventoryLoading,
    InventoryPageHeader,
    inventoryControlClassName,
} from "@/components/inventory/InventoryUi";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SelectField } from "@/components/ui/select-field";
import { useToast } from "@/components/ui/toast";
import {
    type InventoryItem,
} from "@/lib/api/inventory";
import {
    useCreateStockEntryMutation,
    useGetAddOnsQuery,
    useGetCurrentStockQuery,
    useGetInventoryItemOptionsQuery,
} from "@/services/inventoryApi";
import { useMoney } from "@/hooks/useMoney";
import {
    conversionsForOption,
    toEntryUnits,
} from "@/lib/inventory-config/entry-units";

type MovementMode = "in" | "out";

function FormField({
    label,
    name,
    hint,
    error,
    required,
    children,
}: {
    label: string;
    name: string;
    hint?: string;
    error?: string;
    required?: boolean;
    children: ReactNode;
}) {
    return (
        <div className="flex min-w-0 flex-col gap-2">
            <Label
                htmlFor={name}
                className="text-sm font-semibold text-foreground flex items-center gap-1"
            >
                <span>{label}</span>
                {required ? <span className="text-danger">*</span> : null}
            </Label>
            {children}
            {error ? (
                <p className="text-xs text-danger font-medium" role="alert">
                    {error}
                </p>
            ) : hint ? (
                <p className="text-xs text-muted-foreground">{hint}</p>
            ) : null}
        </div>
    );
}

export function StockMovementForm({ mode }: { mode: MovementMode }) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const paramItemId = searchParams?.get("itemId") || "";
    const { toast } = useToast();
    const { format: formatMoney } = useMoney();

    const itemsQuery = useGetInventoryItemOptionsQuery();
    const addOnsQuery = useGetAddOnsQuery();
    const stockQuery = useGetCurrentStockQuery();
    const [createEntry, createState] = useCreateStockEntryMutation();

    // An add-on is counted exactly like an item, so both are recorded here.
    const [target, setTarget] = useState<StockTargetRef | null>(
        paramItemId ? { kind: "ITEM", id: paramItemId } : null,
    );
    /**
     * Which option is being moved.
     *
     * An option counts its own stock, so an item sold in options is stocked
     * through one of them — the API refuses a movement that names none.
     */
    const [optionId, setOptionId] = useState("");
    const [quantityInput, setQuantityInput] = useState("");
    /** Empty means the item's base unit. */
    const [entryUnitId, setEntryUnitId] = useState("");
    const [unitPriceInput, setUnitPriceInput] = useState("");
    const [reasonInput, setReasonInput] = useState("");
    const [batchLot, setBatchLot] = useState("");
    const [batchManufacturedAt, setBatchManufacturedAt] = useState("");
    const [batchExpiresAt, setBatchExpiresAt] = useState("");
    const [scannerOpen, setScannerOpen] = useState(false);
    const [scannedItemName, setScannedItemName] = useState<string | null>(null);
    const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

    const isStockIn = mode === "in";

    if (itemsQuery.isLoading) {
        return <InventoryLoading label={`Loading stock ${mode} form`} />;
    }

    if (itemsQuery.error) {
        return (
            <InventoryError
                message={getApiErrorMessage(
                    itemsQuery.error,
                    `Unable to load items for stock ${mode}.`,
                )}
                retry={itemsQuery.refetch}
            />
        );
    }

    const items = itemsQuery.data || [];
    const addOns = addOnsQuery.data || [];
    const selectedItemId = target?.kind === "ITEM" ? target.id : "";
    const selectedAddOnId = target?.kind === "ADDON" ? target.id : "";
    const selectedItem = items.find((item) => item.id === selectedItemId);
    const selectedAddOn = addOns.find((addOn) => addOn.id === selectedAddOnId);
    const unitLabel =
        selectedItem?.unit?.name || selectedAddOn?.baseUnit?.name || "units";
    /**
     * What each item and add-on holds in total.
     *
     * An item sold in options has one summary per option, so they are summed:
     * keying by item id alone would keep only the last one and read it as the
     * item's whole stock.
     */
    const onHandByTargetId = (stockQuery.data || []).reduce<
        Record<string, number>
    >((totals, summary) => {
        const id = summary.itemId || summary.addOnId || "";
        totals[id] = (totals[id] ?? 0) + (summary.quantityOnHand ?? 0);

        return totals;
    }, {});
    const targets = toStockTargets(items, addOns, onHandByTargetId);
    /**
     * Stock is counted in the item's base unit, but it rarely arrives in one:
     * a delivery is two sacks, not fifty thousand grams. The item's own
     * conversions are what make the larger units selectable here.
     */
    const unitOptions = selectedAddOn
        ? toEntryUnits(selectedAddOn.baseUnit, selectedAddOn.uomConversions || [])
        : toEntryUnits(
              selectedItem?.unit,
              // Narrowed to the option being moved: the same larger unit can
              // be defined for several options and hold a different amount in
              // each, so a list built from all of them offers it more than
              // once and cannot say which one it means.
              conversionsForOption(selectedItem?.uomConversions || [], optionId),
          );
    const selectedUnit =
        unitOptions.find((option) => option.id === entryUnitId) ??
        unitOptions[0];
    const conversionFactor = selectedUnit?.factor || 1;

    const itemOptions = (selectedItem?.variants || [])
        .filter((variant) => variant.id && variant.name?.trim())
        .map((variant) => ({
            id: variant.id || "",
            name: variant.name || "",
        }));

    /**
     * What is on hand where this movement lands: the chosen option's balance,
     * or the target's own when no option is in play.
     */
    const onHand = optionId
        ? ((stockQuery.data || []).find(
              (summary) =>
                  summary.itemId === selectedItemId &&
                  summary.variantId === optionId,
          )?.quantityOnHand ?? 0)
        : ((target ? onHandByTargetId[target.id] : 0) ?? 0);

    const qty = Number(quantityInput);
    const isValidQty = quantityInput.trim() !== "" && Number.isFinite(qty) && qty > 0;
    // What actually moves on the shelf, once the chosen unit is unpacked.
    const baseQty = isValidQty
        ? Math.round(qty * conversionFactor * 1000) / 1000
        : 0;
    const price = Number(unitPriceInput);
    const isValidPrice = unitPriceInput.trim() !== "" && Number.isFinite(price) && price >= 0;

    const resultingStock = isStockIn ? onHand + baseQty : onHand - baseQty;

    const totalValue = isValidPrice ? baseQty * price : 0;

    function handleScannedItem(item: InventoryItem) {
        setTarget({ kind: "ITEM", id: item.id });
        setScannedItemName(item.name || "Unnamed item");
        setFieldErrors((current) => {
            const next = { ...current };
            delete next.itemId;
            return next;
        });
    }

    async function handleSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        const errors: Record<string, string> = {};

        if (!target) {
            errors.itemId = "Please select an item or add-on.";
        }

        // An option counts its own stock, so the API refuses a movement on an
        // item sold in options that does not say which one.
        if (itemOptions.length && !optionId) {
            errors.variantId = "Please choose which option this is for.";
        }

        if (!isValidQty) {
            errors.quantity = "Please enter a valid quantity greater than 0.";
        }

        if (unitPriceInput.trim() !== "" && (!Number.isFinite(price) || price < 0)) {
            errors.unitPrice = "Unit price cannot be negative.";
        }

        // Stock arriving has to say what it cost: the shelf's value, every
        // sale's cost and every selling price are all set against it. Zero is
        // a fine answer for free stock — saying nothing is not.
        if (isStockIn && unitPriceInput.trim() === "") {
            errors.unitPrice =
                "Enter what one unit cost. Put 0 if this stock was free.";
        }

        if (!reasonInput.trim()) {
            errors.reason = "Please enter a reason for this stock change.";
        }

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            toast({
                tone: "error",
                title: "Incomplete stock entry",
                description: Object.values(errors)[0],
            });
            return;
        }

        setFieldErrors({});

        const quantityChange = isStockIn ? baseQty : -baseQty;
        const batchData: Record<string, string> = {};
        if (batchLot.trim()) batchData.lot = batchLot.trim();
        if (batchManufacturedAt.trim()) batchData.manufacturedAt = batchManufacturedAt.trim();
        if (batchExpiresAt.trim()) batchData.expiresAt = batchExpiresAt.trim();

        try {
            await createEntry({
                ...(target?.kind === "ADDON"
                    ? { addOnId: target.id }
                    : {
                          itemId: selectedItemId,
                          ...(optionId ? { variantId: optionId } : {}),
                      }),
                entryType: isStockIn ? "STOCK_IN" : "STOCK_OUT",
                quantityChange,
                // Cost on the way in, sale price on the way out. The API
                // refuses the wrong one, because a sale price stored as cost
                // used to become the item's cost for everything after it.
                unitCost: isStockIn && isValidPrice ? price : undefined,
                unitSalePrice:
                    !isStockIn && isValidPrice ? price : undefined,
                // Kept so the ledger reads "2 sacks", not just the base amount.
                enteredQuantity: selectedUnit ? qty : undefined,
                unitId: selectedUnit?.id,
                batchData,
                referenceType: isStockIn ? "STOCK_IN_FORM" : "STOCK_OUT_FORM",
                referenceId: "",
                referenceNumber: "",
                reason: reasonInput.trim(),
            }).unwrap();

            toast({
                tone: "success",
                title: isStockIn ? "Stock in recorded" : "Stock out recorded",
                description: `${isStockIn ? "Added" : "Deducted"} ${qty} ${unitLabel} ${isStockIn ? "to" : "from"} ${selectedItem?.name || "item"}.`,
            });

            router.push("/inventory/stock");
        } catch (error) {
            toast({
                tone: "error",
                title: `Stock ${mode} failed`,
                description: getApiErrorMessage(
                    error,
                    `Unable to save stock ${mode} movement.`,
                ),
            });
        }
    }

    return (
        <>
            <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-6">
                <InventoryPageHeader
                    title={isStockIn ? "Stock In" : "Stock Out"}
                    description={
                        isStockIn
                            ? "Record incoming inventory received into your stock."
                            : "Record outgoing inventory deductions or removals from your stock."
                    }
                    action={
                        <Button
                            variant="outline"
                            render={<Link href="/inventory/stock" />}
                            nativeButton={false}
                            className="h-10 gap-2 rounded-xl"
                        >
                            <ArrowLeft className="size-4" />
                            Back to stock
                        </Button>
                    }
                />

                <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px] items-start">
                    {/* Main Form Section */}
                    <section className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-7 flex flex-col gap-6">
                        <div className="flex items-center gap-3.5 border-b border-border pb-5">
                            <span
                                className={`grid size-11 shrink-0 place-items-center rounded-2xl ${
                                    isStockIn
                                        ? "bg-primary/10 text-primary"
                                        : "bg-danger/10 text-danger"
                                }`}
                            >
                                {isStockIn ? (
                                    <ArrowDownRight className="size-6" />
                                ) : (
                                    <ArrowUpRight className="size-6" />
                                )}
                            </span>
                            <div>
                                <h2 className="text-lg font-semibold text-foreground">
                                    {isStockIn ? "Stock In Movement" : "Stock Out Movement"}
                                </h2>
                                <p className="text-xs text-muted-foreground">
                                    Select an item, specify quantity, price, and reason for this change.
                                </p>
                            </div>
                        </div>

                        {items.length === 0 ? (
                            <div className="rounded-xl border border-warning/40 bg-warning/10 p-4 text-sm text-warning">
                                No items found. Create items in Inventory before recording stock changes.
                            </div>
                        ) : (
                            <div className="grid gap-5 sm:grid-cols-2">
                                {/* Item Selector */}
                                <div className="sm:col-span-2">
                                    <FormField
                                        label="Item"
                                        name="itemId"
                                        required
                                        hint={
                                            scannedItemName
                                                ? `${scannedItemName} selected by scanner.`
                                                : "Search item by name, SKU, or barcode."
                                        }
                                        error={fieldErrors.itemId}
                                    >
                                        <div className="flex gap-2">
                                            <StockTargetSelect
                                                targets={targets}
                                                selected={target}
                                                onSelect={(picked) => {
                                                    setTarget(picked);
                                                    setEntryUnitId("");
                                                    setOptionId("");
                                                    setScannedItemName(null);
                                                    setFieldErrors((current) => {
                                                        const next = { ...current };
                                                        delete next.itemId;
                                                        return next;
                                                    });
                                                }}
                                                ariaInvalid={Boolean(
                                                    fieldErrors.itemId,
                                                )}
                                            />
                                            <Button
                                                type="button"
                                                variant="outline"
                                                size="icon-lg"
                                                onClick={() => setScannerOpen(true)}
                                                title="Scan item barcode"
                                            >
                                                <ScanBarcode />
                                            </Button>
                                        </div>
                                    </FormField>
                                </div>

                                {/* Which option, when the item has any. Each
                                    counts its own stock, so one must be named. */}
                                {itemOptions.length ? (
                                    <div className="sm:col-span-2">
                                        <FormField
                                            label="Option"
                                            name="variantId"
                                            required
                                            hint="Each option counts its own stock, so this movement lands on the one you choose."
                                            error={fieldErrors.variantId}
                                        >
                                            <SelectField
                                                id="variantId"
                                                name="variantId"
                                                value={optionId}
                                                onValueChange={(value) => {
                                                    setOptionId(value);
                                                    setFieldErrors((current) => {
                                                        const next = { ...current };
                                                        delete next.variantId;
                                                        return next;
                                                    });
                                                }}
                                                placeholder="Choose an option"
                                                options={itemOptions.map(
                                                    (option) => ({
                                                        value: option.id,
                                                        label: option.name,
                                                    }),
                                                )}
                                                className={inventoryControlClassName}
                                            />
                                        </FormField>
                                    </div>
                                ) : null}

                                {/* Quantity Input */}
                                <FormField
                                    label="Quantity"
                                    name="quantity"
                                    required
                                    hint={
                                        selectedItemId
                                            ? `Current stock: ${onHand} ${unitLabel}`
                                            : "Number of units to adjust."
                                    }
                                    error={fieldErrors.quantity}
                                >
                                    <div className="flex items-center gap-2">
                                        <Input
                                            id="quantity"
                                            name="quantity"
                                            type="number"
                                            step="0.01"
                                            min="0.01"
                                            value={quantityInput}
                                            onKeyDown={(e) => {
                                                if (e.key === "-" || e.key === "e") {
                                                    e.preventDefault();
                                                }
                                            }}
                                            onChange={(e) => {
                                                const val = e.target.value.replace(/-/g, "");
                                                setQuantityInput(val);
                                                setFieldErrors((current) => {
                                                    const next = { ...current };
                                                    delete next.quantity;
                                                    return next;
                                                });
                                            }}
                                            placeholder="e.g. 50"
                                            className={`${inventoryControlClassName} flex-1`}
                                        />
                                        {unitOptions.length > 1 ? (
                                            <select
                                                aria-label="Unit"
                                                value={selectedUnit?.id || ""}
                                                onChange={(event) =>
                                                    setEntryUnitId(
                                                        event.target.value,
                                                    )
                                                }
                                                className="shrink-0 rounded-lg border border-border bg-card px-2.5 py-2 text-xs font-semibold text-foreground outline-none"
                                            >
                                                {unitOptions.map((option) => (
                                                    <option
                                                        key={option.id}
                                                        value={option.id}
                                                    >
                                                        {option.label}
                                                    </option>
                                                ))}
                                            </select>
                                        ) : selectedItemId ? (
                                            <span className="text-xs font-semibold text-muted-foreground shrink-0 bg-muted px-2.5 py-2 rounded-lg border border-border">
                                                {unitLabel}
                                            </span>
                                        ) : null}
                                    </div>
                                    {conversionFactor !== 1 && isValidQty ? (
                                        <p className="text-xs text-muted-foreground">
                                            {qty} {selectedUnit?.label} ={" "}
                                            {baseQty} {unitLabel}
                                        </p>
                                    ) : null}
                                </FormField>

                                {/* Cost on the way in, sale price on the way out. */}
                                <FormField
                                    label={
                                        isStockIn
                                            ? "Cost per unit"
                                            : "Sale price per unit"
                                    }
                                    name="unitPrice"
                                    required={isStockIn}
                                    hint={
                                        isStockIn
                                            ? `What one ${selectedItem?.unit?.name || "unit"} was bought for. Stock is valued from this, oldest batch first, and it is what a selling price is set against. Enter 0 if it was free.`
                                            : `What one ${selectedItem?.unit?.name || "unit"} sold for, if this is a sale made away from the till. Leave empty for waste or damage — the cost is worked out from the batches it came from.`
                                    }
                                    error={fieldErrors.unitPrice}
                                >
                                    <Input
                                        id="unitPrice"
                                        name="unitPrice"
                                        type="number"
                                        step="0.01"
                                        min="0"
                                        value={unitPriceInput}
                                        onKeyDown={(e) => {
                                            if (e.key === "-" || e.key === "e") {
                                                e.preventDefault();
                                            }
                                        }}
                                        onChange={(e) => {
                                            const val = e.target.value.replace(/-/g, "");
                                            setUnitPriceInput(val);
                                            setFieldErrors((current) => {
                                                const next = { ...current };
                                                delete next.unitPrice;
                                                return next;
                                            });
                                        }}
                                        placeholder="0.00"
                                        className={inventoryControlClassName}
                                    />
                                </FormField>

                                {/* Reason Input */}
                                <div className="sm:col-span-2">
                                    <FormField
                                        label="Reason"
                                        name="reason"
                                        required
                                        hint={
                                            isStockIn
                                                ? "Enter reason for stock in (e.g. Supplier delivery, Restock, PO-2026-001)"
                                                : "Enter reason for stock out (e.g. Damaged item, Expired, Waste)"
                                        }
                                        error={fieldErrors.reason}
                                    >
                                        <Input
                                            id="reason"
                                            name="reason"
                                            value={reasonInput}
                                            onChange={(e) => {
                                                setReasonInput(e.target.value);
                                                setFieldErrors((current) => {
                                                    const next = { ...current };
                                                    delete next.reason;
                                                    return next;
                                                });
                                            }}
                                            placeholder={
                                                isStockIn
                                                    ? "e.g. Supplier purchase, Restock, Customer return"
                                                    : "e.g. Damaged item, Expired, Internal consumption"
                                            }
                                            className={inventoryControlClassName}
                                        />
                                    </FormField>
                                </div>

                                {/* Batch Details Card */}
                                <div className="sm:col-span-2 rounded-xl border border-border bg-transparent p-4 sm:p-5">
                                    <div className="flex items-start gap-3">
                                        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                                            <PackageOpen className="size-5" />
                                        </span>
                                        <div>
                                            <h3 className="font-semibold text-foreground">
                                                Batch details
                                            </h3>
                                            <p className="mt-1 text-xs sm:text-sm text-muted-foreground">
                                                Optional. Use these fields when stock is tracked by lot or expiration date. No JSON is required.
                                            </p>
                                        </div>
                                    </div>

                                    <div className="mt-4 grid gap-4 sm:grid-cols-3">
                                        <FormField
                                            label="Batch / lot number"
                                            name="batchLot"
                                            hint="For example, LOT-01."
                                        >
                                            <Input
                                                id="batchLot"
                                                name="batchLot"
                                                value={batchLot}
                                                onChange={(e) => setBatchLot(e.target.value)}
                                                placeholder="LOT-01"
                                                className={inventoryControlClassName}
                                            />
                                        </FormField>
                                        <FormField
                                            label="Manufactured date"
                                            name="batchManufacturedAt"
                                        >
                                            <Input
                                                id="batchManufacturedAt"
                                                name="batchManufacturedAt"
                                                type="date"
                                                value={batchManufacturedAt}
                                                onChange={(e) => setBatchManufacturedAt(e.target.value)}
                                                className={inventoryControlClassName}
                                            />
                                        </FormField>
                                        <FormField
                                            label="Expiration date"
                                            name="batchExpiresAt"
                                        >
                                            <Input
                                                id="batchExpiresAt"
                                                name="batchExpiresAt"
                                                type="date"
                                                value={batchExpiresAt}
                                                onChange={(e) => setBatchExpiresAt(e.target.value)}
                                                className={inventoryControlClassName}
                                            />
                                        </FormField>
                                    </div>
                                </div>
                            </div>
                        )}
                    </section>

                    {/* Side Live Summary Panel */}
                    <div className="flex flex-col gap-4 sticky top-6">
                        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                            <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 border-b border-border pb-3">
                                <Calculator className="size-4 text-primary" />
                                <span>Movement Summary</span>
                            </h3>

                            <div className="mt-4 flex flex-col gap-3.5 text-sm">
                                <div className="flex justify-between items-center text-muted-foreground">
                                    <span>Selected Item</span>
                                    <span className="font-medium text-foreground truncate max-w-[160px]">
                                        {selectedItem ? selectedItem.name : "None"}
                                    </span>
                                </div>

                                <div className="flex justify-between items-center text-muted-foreground">
                                    <span>Current Stock</span>
                                    <span className="font-semibold text-foreground">
                                        {selectedItemId ? `${onHand} ${unitLabel}` : "-"}
                                    </span>
                                </div>

                                <div className="flex justify-between items-center text-muted-foreground">
                                    <span>Adjustment</span>
                                    <span
                                        className={`font-semibold ${
                                            isStockIn ? "text-primary" : "text-danger"
                                        }`}
                                    >
                                        {isValidQty
                                            ? `${isStockIn ? "+" : "-"}${qty} ${unitLabel}`
                                            : "-"}
                                    </span>
                                </div>

                                <div className="border-t border-border pt-3 flex justify-between items-center">
                                    <span className="font-medium text-foreground">Projected Stock</span>
                                    <span
                                        className={`text-base font-bold ${
                                            !isStockIn && resultingStock < 0
                                                ? "text-danger"
                                                : "text-foreground"
                                        }`}
                                    >
                                        {selectedItemId && isValidQty
                                            ? `${resultingStock} ${unitLabel}`
                                            : selectedItemId
                                              ? `${onHand} ${unitLabel}`
                                              : "-"}
                                    </span>
                                </div>

                                {!isStockIn && isValidQty && resultingStock < 0 ? (
                                    <p className="text-xs text-danger bg-danger/10 p-2.5 rounded-lg border border-danger/20">
                                        Warning: This stock out exceeds the current on-hand quantity!
                                    </p>
                                ) : null}

                                <div className="border-t border-border pt-3 flex justify-between items-center">
                                    <span className="font-medium text-foreground">Total Value</span>
                                    <span className="text-base font-bold text-primary">
                                        {formatMoney(totalValue)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-col gap-2.5">
                            <Button
                                type="submit"
                                size="lg"
                                disabled={createState.isLoading || items.length === 0}
                                className={`w-full rounded-xl gap-2 ${
                                    !isStockIn ? "bg-danger hover:bg-danger/90 text-white" : ""
                                }`}
                            >
                                {createState.isLoading ? (
                                    <LoaderCircle className="size-4 animate-spin shrink-0" />
                                ) : (
                                    <Check className="size-4 shrink-0" />
                                )}
                                <span>{isStockIn ? "Save Stock In" : "Save Stock Out"}</span>
                            </Button>



                            <Button
                                type="button"
                                variant="outline"
                                render={<Link href="/inventory/stock" />}
                                nativeButton={false}
                                className="w-full rounded-xl"
                            >
                                Cancel
                            </Button>
                        </div>
                    </div>
                </div>
            </form>

            <BarcodeScannerOverlay
                open={scannerOpen}
                onOpenChange={setScannerOpen}
                onItemFound={handleScannedItem}
            />
        </>
    );
}
